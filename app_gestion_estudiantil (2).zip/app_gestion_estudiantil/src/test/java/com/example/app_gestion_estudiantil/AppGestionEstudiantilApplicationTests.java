package com.example.app_gestion_estudiantil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGestionEstudiantilApplicationTests {

    @Test
    void contextLoads() {
    }

}
