package com.example.app_gestion_estudiantil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppGestionEstudiantilApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppGestionEstudiantilApplication.class, args);
    }

}
