package com.example.app_gestion_estudiantil.user;

public enum Role {
    USER,
    ADMIN
}
