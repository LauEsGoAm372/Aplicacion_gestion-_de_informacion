package com.example.app_gestion_estudiantil.controller;

import com.example.app_gestion_estudiantil.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserService userService;

    //
    //@GetMapping("/getbuscar/{apodo}")
    //public User getUserByApodo(@PathVariable String apodo){
    //   return userService.getUserByApodo(apodo);
    //}



}
