import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

export const sendData = (apodo, firstname,email, password) => {
  if (!apodo || !firstname ||  !email || !password ) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Todos los campos son necesarios',
      confirmButtonText: 'Aceptar',
    });
    return;
  }

  const data = {
    apodo: apodo,
    firstname: firstname,
    email: email,
    password: password,
  };

  fetch('/api/auth/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => {
      Cookies.set('token', data.token);
      Swal.fire({
        icon: 'success',
        title: 'Registro Exitoso',
        showConfirmButton: false,
        timer: 700,
      });
      setTimeout(() => {
        window.location.replace('/login.html');
      }, 1000);
    })
    .catch((error) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Hubo un error en el registro',
        confirmButtonText: 'Aceptar',
      });
    });
};
/*
import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

export const sendData = (apodo, firstname, lastname, email, password, image) => {
  if (!apodo || !firstname || !lastname || !email || !password || !image) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Todos los campos son necesarios',
      confirmButtonText: 'Aceptar',
    });
    return;
  }

  const data = {
    apodo: apodo,
    firstname: firstname,
    lastname: lastname,
    email: email,
    password: password,
    image: image,
  };

  fetch('/api/auth/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((data) => {
      Cookies.set('token', data.token);
      Swal.fire({
        icon: 'success',
        title: 'Registro Exitoso',
        showConfirmButton: false,
        timer: 700,
      });
      setTimeout(() => {
        window.location.replace('/login.html');
      }, 1000);
    })
    .catch((error) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Hubo un error en el registro',
        confirmButtonText: 'Aceptar',
      });
    });
};
*/
