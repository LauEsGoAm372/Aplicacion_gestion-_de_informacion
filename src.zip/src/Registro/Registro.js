import React, { useState } from "react";
import "./Registro.css";
import { sendData } from './Funciones.Res.js';

export const Registro = () => {

    const [apodo, setApodo] = useState("");
    const [firstname, setFirstname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = () => {
        sendData(apodo, firstname, email, password);
    };

    return (
        <div className="registro">
            <div className="overlap-wrapper">
                <div className="overlap">
                    <div className="soporte">
                        <div className="overlap-group">
                            <p className="necesitas-ayuda">
                                <span className="text-wrapper">Necesitas Ayuda ? </span>
                                <span className="span">Soporte</span>
                            </p>
                        </div>
                    </div>
                    <div className="figuras-y-fondo">
                        <div className="div">
                            <div className="rectangle" />
                            <div className="rectangle-2" />
                            <div className="rectangle-3" />
                        </div>
                    </div>
                    <div className="imagenes" />
                    <div className="button-registrar">
                        <div>
                            <button className="btn btn-custom"  onClick={handleSubmit} >Registrate !</button>
                        </div>
                    </div>
                    <div className="datos-registro">
                        <div className="text-wrapper-3">Nombre de Usuario :</div>
                        <div className="text-wrapper-4">Nombre Completo</div>
                        <div className="text-wrapper-5">Contraseña :</div>
                        <div className="text-wrapper-6">Email:</div>
                        <p className="p">Por favor completa el Formulario de Registro !</p>
                    </div>
                    <div className="espacios-input">
                        <input className="nombre-usuario" value={apodo} onChange={(e) => setApodo(e.target.value)}/>
                        <input className="nombre-completo" value={firstname} onChange={(e) => setFirstname(e.target.value)}/>
                        <input className="entrada-contrasea" value={password} onChange={(e) => setPassword(e.target.value)}/>
                        <input className="entrada-email" value={email} onChange={(e) => setEmail(e.target.value)}/>
                    </div>
                </div>
            </div>
        </div>
    );
};

