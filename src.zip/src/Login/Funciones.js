import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

export const sendData = (email, password) => {
    const data = {
        email: email,
        password: password
      };
    fetch('/api/auth/authenticate', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/json',
       },
        body: JSON.stringify(data),
    })
    .then((response) => response.json())
    .then((data) => {
      console.log("Holaaaa")
      Cookies.set('token', data.token);
      Swal.fire({
        icon: 'success',
        title: 'Registro Exitoso',
        showConfirmButton: false,
        timer: 700,
      });
      
    })
    .catch((error) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Hubo un error en el registro',
        confirmButtonText: 'Aceptar',
      });
    });
}