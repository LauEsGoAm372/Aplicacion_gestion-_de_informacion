import React, { useState } from "react";
import "./Login.css";
import { sendData } from './Funciones.js';

export const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = () => {
        sendData(email, password);
    };

    return (
        <div className="login">
            <div className="overlap-wrapper">
                <div className="overlap">
                    <div className="figuras-y-fondo">
                        <div className="overlap-group">
                            <div className="rectangle" />
                            <div className="div" />
                            <div className="rectangle-2" />
                            <div className="rectangle-3" />
                        </div>
                    </div>
                    <div className="imagenes-y-vectores" />
                    <div className="boton-ingreso">
                        <button className="btn btn-custom" onClick={handleSubmit}>Ingresar</button>
                    </div>
                    <div className="overlap-group-wrapper">
                    </div>
                    <div className="datos-ingreso">
                        <input className="usuario-entrada" value={email} onChange={(e) => setEmail(e.target.value)}/>
                        <input className="contrasea-entrada" value={password} onChange={(e) => setPassword(e.target.value)}/>
                        <div className="text-wrapper-2">Nombre de Usuario :</div>
                        <div className="text-wrapper-3">Contraseña :</div>
                        <div className="text-wrapper-4">Bienvenido Nuevamente!</div>
                    </div>
                </div>
            </div>
        </div>
    );
};
